<div class="contentHdr">
<div class="title">
  <span>Online <span>Booking</span></span>
</div>
</div>
<div class="content">
<table width="100%" border="0" cellspacing="0" cellpadding="5">
  <tr>
    <td width="60%" rowspan="5" valign="top" class="tblHdr">Select Your Destination :</td>
    <td width="40%" class="tblContent2"><input name="destination" type="checkbox" value="" />&nbsp;&nbsp;&nbsp;Nepal</td>
  </tr>
  <tr>
    <td class="tblContent2"><input name="destination" type="checkbox" value="" />&nbsp;&nbsp;&nbsp;Tibet</td>
  </tr>
  <tr>
    <td class="tblContent2"><input name="destination" type="checkbox" value="" />&nbsp;&nbsp;&nbsp;Bhutan</td>
  </tr>
  <tr>
    <td class="tblContent2"><input name="destination" type="checkbox" value="" />&nbsp;&nbsp;&nbsp;India</td>
  </tr>
  <tr>
    <td class="tblContent" style="padding-bottom:10px;"><input name="destination" type="checkbox" value="" />&nbsp;&nbsp;&nbsp;Shree Lanka</td>
  </tr>
  <tr>
    <td class="tblHdr">Duration Of the Holiday : <span>*</span></td>
    <td class="tblContent"><input name="duration" type="text" class="txtFieldDuration" /></td>
  </tr>
  <tr>
    <td rowspan="5" class="tblHdr" style="line-height:20px; padding:10px 15px 10px 0;" valign="top">Are you interested in further information on other activities :</td>
    <td class="tblContent2" style="padding-top:10px;"><input name="destination" type="checkbox" value="" />&nbsp;&nbsp;&nbsp;Expeditions</td>
  </tr>
  <tr>
    <td class="tblContent2"><input name="destination" type="checkbox" value="" />&nbsp;&nbsp;&nbsp;Jungle Safari</td>
  </tr>
  <tr>
    <td class="tblContent2"><input name="destination" type="checkbox" value="" />&nbsp;&nbsp;&nbsp;Trekking</td>
  </tr>
  <tr>
    <td class="tblContent2"><input name="destination" type="checkbox" value="" />&nbsp;&nbsp;&nbsp;Rafting</td>
  </tr>
  <tr>
    <td class="tblContent" style="padding-bottom:10px;"><input name="destination" type="checkbox" value="" />&nbsp;&nbsp;&nbsp;Sightseeing</td>
  </tr>
  <tr>
    <td class="tblHdr">Full Name : <span>*</span></td>
    <td class="tblContent"><input name="name" type="text" class="txtField" /></td>
  </tr>
  <tr>
    <td class="tblHdr">Address : </td>
    <td class="tblContent"><textarea name="address" cols="5" rows="5" class="txtArea">&nbsp;</textarea></td>
  </tr>
  <tr>
    <td class="tblHdr">E-mail : <span>*</span></td>
    <td class="tblContent"><input name="email" type="text" class="txtField" /></td>
  </tr>
  <tr>
    <td class="tblHdr">Nationality :</td>
    <td class="tblContent"><input name="nationality" type="text" class="txtField" /></td>
  </tr>
  <tr>
    <td class="tblHdr">When You want to go</td>
    <td class="tblContent">
      <select name="month">
        <option>-- Select Month --</option>
      </select>
      
      <select name="year">
        <option>-- Select Year --</option>
      </select>
      </td>
  </tr>
  <tr>
    <td class="tblHdr">Any Further information or request :</td>
    <td class="tblContent"><textarea name="info" cols="5" rows="5" class="txtArea">&nbsp;</textarea></td>
  </tr>
  <tr>
    <td rowspan="2" class="tblHdr">Security Code : <span>*</span></td>
    <td class="tblContent" style="padding-top:10px; border-bottom:0px;">
  <img src="images/capcha.jpg" alt="Capcha" /><a href="#">[ Reload Image ]</a>
    </td>
  </tr>
  <tr>
    <td class="tblContent" style="line-height:0px;"><input name="capcha" type="text" class="txtField" /></td>
  </tr>
  <tr>
    <td style="padding-top:10px;">[ Fields marked with <span>*</span> are compulsory Fields ]</td>
    <td><input name="submit" type="button" value="Submit" class="btnSubmit" /></td>
  </tr>
  </table>
  </div>