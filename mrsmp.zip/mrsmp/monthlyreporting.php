<tr>
    	<td><strong>जिल्ला</strong></td>
          <td><select name="district">
    
    	<option value="palpa">पाल्पा</option>
        <option value="rupendehi">रुपन्देही</option></td>
        
    </select>
         </td></tr>
     <tr>
     	<td>
         <strong>आ.व.</strong></td><td><input type="text" name="ecoYear">
     </td></tr>
    <tr><td>
         		<strong>महिना</strong> </td><td><input type="text" name="month"></td></tr>
    </td></tr>
    <tr><td>
    <strong> बालीको नाम</strong></td><td><input type="text" name="cropName"></td></tr>
    <tr><td>
    <strong>बाली स्थिती	</strong></td>
         		
              <td>
    
         		बाली लगाउने कार्य भैरहेको (%)&nbsp;<input type="text" name="cropWork">
                
                बाली बढने अवस्था(%)&nbsp;<input type="text" name="cropGrowth">
   			
         		बालीको फूल लाग्ने अवस्था  (%)&nbsp;<input type="text" name="cropMaturity">
   
         		बाली कटानी भैरहेको(%)&nbsp;<input type="text" name="cropHarvest">
                
   			 </td></tr>
    <tr>
    <td>
    <strong>दैवि प्रकोपको असर</strong></td>
    	<td>
        	दैविप्रकोपको किसिम, सम्बन्धित कोड लेख्ने <select name="naturalDisaster">
    
    	<option value="heavyRainfall">अतिवृष्टि</option>
        <option value="flood">बाढी</option>
       	<option value="landslide">पहिरो</option>
        <option value="dry">सुख्खा</option>
        <option value="drought">अनावृष्टि</option>
        <option value="strom">हुरीबतास</option>
        <option value="hailStrom">असिना</option>
        <option value="diseaseInsects">रोगकीरा </option>
        <option value="any">अन्य खुलाउने</option>
        
    </select>
         प्रभावित क्षेत्रफल  (%)&nbsp;<input type="text" name="affectedArea">
    
        प्रभावित परिवार संख्या&nbsp;<input type="text" name="affectFamilyNo">
   
         उत्पादनमा क्षती मे.टन&nbsp;</strong><input type="text" name="productionLoass">
      </td></tr>
     <tr><td>
        	<strong>बर्षा स्थिती</strong></td><td><select name="rainfall">
    
    	<option value="bad">नराम्रो</option>
        <option value="basic">सामान्य</option>
        <option value="good">राम्रो</option></td>
        
    </select>
         </td></tr>
     <tr><td>
        	<strong>तापक्रम</strong></td><td><select name="temperature">
    
  		<option value="bad">नराम्रो</option>
        <option value="basic">सामान्य</option>
        <option value="good">राम्रो</option></td>
        
    </select>
         </td></tr>
     <tr><td>
        	<strong>रासायनिक मलको आपुर्ति</strong></td><td><select name="fertilizerConsumption">
    
  		<option value="enough">पर्याप्त</option>
        <option value="basic">सामान्य</option>
        <option value="insufficient">अपर्याप्त</option></td>
        
    </select>
         </td></tr>     
       
     <tr><td>
         		<strong>बाली लगाउन समाप्त भएको कुल क्षेत्रफल (हे.)</strong></td><td><input type="text" name=""></td></tr>
    </td></tr>
     <tr><td>
         		<strong>फूलफुल्ने अवस्था भए आशातित र कटानी भई सकेको भए वास्तविक उत्पादन(मे.टन)</strong></td><td><input type="text" name="">
     </td></tr>
    </td></tr>
     <tr><td>
         		<strong>गतबर्षको दाजोमा क्षेत्रफलमा बढि (+), घटि (–) (हेक्टर)</strong></td><td><input type="text" name="">
    </td></tr>
    </td></tr>
     <tr><td>
         		<strong>गत बर्षको  दाजोमा उत्पादन बढि(+), घटि (–) (मे.टन)</strong></td><td><input type="text" name="">
    </td></tr>
    </td></tr>
    <tr><td>
         		<strong> कैफियत</strong></td><td><textarea name="remarks" rows="4" cols="70"></textarea>
    </td></tr>
     
     
     <tr><td>&nbsp;</td></tr>
<tr>
	<td></td>
	<td><input type="submit" class="button" name="save" value="Save" /></td>
</tr>
<tr><td><br></td></tr>