<style>
	.name {color: red;float: left;font-size: 17px;margin: 9% 0 0 5%;}
</style>
<!-- Sitelogo and sitename -->
<div class="logo">
    <a class="sitelogo" href="<?=SITE_URL;?>"><img src="img/home.png" /></a>
</div>
<div class="sitename">
    <? include("program/title.php");?>
</div>

<!-- Navigation Level 0 -->
<div class="nav0">
    <img src="img/flagnepal.gif" style=" width:85px" />
</div>
<div style="clear:both"></div>