<style>
	.prtitle {border-bottom: 2px solid;color: #004600;font-size: 17px;font-weight: bold;margin: 0 25px;padding: 15px 0 5px;}
	.master{background-image:url(img/prhome.png); height:458px;}
</style>
<div class="master">
    <div class="prtitle">
		<? //echo $userGet['name'];?>Agriculture Information Management System
	</div>
</div>