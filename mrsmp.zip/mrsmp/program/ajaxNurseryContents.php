<tr>
	<td><strong>&#2344;&#2352;&#2381;&#2360;&#2352;&#2367;&#2325;&#2379; &#2346;&#2381;&#2352;&#2325;&#2366;&#2352; :</strong> <span class="asterisk">*</span></td>
    <td>
    	<select name="nursery_type" style="width:200px">
        	<option value="select">&#2344;&#2352;&#2381;&#2360;&#2352;&#2367;&#2325;&#2379; &#2346;&#2381;&#2352;&#2325;&#2366;&#2352;</option>
            <option value="vegetable">&#2340;&#2352;&#2325;&#2366;&#2352;&#2368;</option>
            <option value="vegetable">&#2347;&#2354;&#2347;&#2369;&#2354;</option>
            <option value="vegetable">&#2347;&#2369;&#2354;</option>
            <option value="vegetable">&#2350;&#2366;&#2331;&#2366;</option>
            <option value="vegetable">&#2309;&#2344;&#2381;&#2351;</option>
        </select>
  	</td>
</tr>

<tr>
	<td><strong>&#2344;&#2352;&#2381;&#2360;&#2352;&#2367;&#2325;&#2379; &#2360;&#2306;&#2326;&#2381;&#2351;&#2366; :<span class="asterisk">*</span></strong></td>
    <td><input type="text" name="nursery_number" class="text" value="<?=$groupRow['nursery_number'];?>" /></td>
</tr>

<tr>
	<td><strong>&#2313;&#2340;&#2381;&#2346;&#2366;&#2342;&#2344; &#2360;&#2306;&#2326;&#2381;&#2351;&#2366; :</strong><span class="asterisk">*</span></td>
    <td><input type="text" name="production_number" class="text" value="<?=$groupRow['production_number'];?>" /></td>
</tr>

<tr>
	<td><strong>&#2357;&#2367;&#2340;&#2352;&#2339; &#2360;&#2306;&#2326;&#2381;&#2351;&#2366; :</strong><span class="asterisk">*</span></td>
    <td><input type="text" name="distribution_number" class="text" value="<?=$groupRow['distribution_number'];?>" /></td>
</tr>