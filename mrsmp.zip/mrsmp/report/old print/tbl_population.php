<tr>
    <td><span class="title">जम्मा</span> :</td>
    <td>
        <div class="inputleft">
            <div>परिवार संख्या</div>
            <div><?=$row['totalFamilyNumber'];?></div>
            <div style="clear:both"></div>
        </div>
        <div class="inputleft inputright">
            <div>जनसंख्या</div>
            <div><?=$row['totalPopulation'];?></div>
            <div style="clear:both"></div>
        </div>
        <div style="clear:both"></div>
    </td>
</tr>
<tr>
    <td><span class="title">कृषक </span> :</td>
    <td>
        <div class="inputleft">
            <div>परिवार संख्या</div>
            <div><?=$row['farmerFamilyNumber'];?></div>
            <div style="clear:both"></div>
        </div>
        <div class="inputleft inputright">
            <div>जनसंख्या</div>
            <div><?=$row['farmerPopulation'];?></div>
            <div style="clear:both"></div>
        </div>
        <div style="clear:both"></div>
    </td>
</tr>
<tr>
    <td><span class="title">कृषक </span> :</td>
    <td>
        <div class="inputleft">
            <div>महिला संख्या</div>
            <div><?=$row['femaleNumber'];?></div>
            <div style="clear:both"></div>
        </div>
        <div class="inputleft inputright">
            <div>पुरुष संख्या</div>
            <div><?=$row['maleNumber'];?></div>
            <div style="clear:both"></div>
        </div>
        <div style="clear:both"></div>
    </td>
</tr>