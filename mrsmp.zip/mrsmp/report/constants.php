<?php
	//for report central
	define("USERDISTRICT", 2);
?>