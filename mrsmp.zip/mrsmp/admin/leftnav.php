<ul class="menu">
	<li>
  		<p>Admin Site</p>
  		<ul>
    		<li><a href="index.php">Home</a></li>
      		<li><a href="changepswd.php">Change Password</a></li>
      		<li><a href="logout.php">Logout</a></li>
    	</ul>
  	</li>
  	<li>
  		<p>Manage Info</p>
    	<ul>
            <li><a href="cms.php">Manage Contents</a></li>
            <li><a href="cms.php?groupType=Header">Menubar</a></li>
            
            <li><a href="cms.php?parentId=241&groupType=Other&open">Information Categories</a></li>
            <li><a href="cms.php?parentId=275&groupType=Other&open">Important Links</a></li>
            <li><a href="cms.php?id=176&parentId=0&groupType=Other">Welcome Message</a></li>
            <li><a href="cms.php?id=274&parentId=0&groupType=Other">Message From Program Chief</a></li>
            <li><a href="cms.php?parentId=332&groupType=Other&open">Previous Instruments</a></li>
            <!--<li><a href="feedbacks.php">View Feedbacks</a></li>
            <li><a href="enewsletters.php">View Suscribes</a></li>-->
            <li><a href="bills.php">Manage Bills</a></li>
            <li><a href="cms.php?groupType=Other">Manage Other</a></li>
    	</ul>
  	</li>
  	<li>
  		<p>Manage Program Info</p>
        <ul>
            <li><a href="programtype.php">Manage Program Type</a></li>
            <li><a href="programlevel.php">Manage Program Level</a></li>
            <li><a href="usertype.php">Manage User Type</a></li>
            <li><a href="users.php">Manage Users</a></li>
            <li><a href="unit.php">Manage Units</a></li>
        </ul>
  	</li>
    <li>
  		<p>Manage Crops</p>
        <ul>
            <li><a href="crop.php">Manage Crop List</a></li>
            <li><a href="cropprice.php">Manage Crops for Price List</a></li>
        </ul>
  	</li>
</ul>